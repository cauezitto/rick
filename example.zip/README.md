# DisTube Example

DisTube.js.org example music bot with command handler

**Dependencies maybe outdated. You should update them yourself!**

Check out the [official guide](https://distube.js.org/guide) to get your music bot running from scratch.
